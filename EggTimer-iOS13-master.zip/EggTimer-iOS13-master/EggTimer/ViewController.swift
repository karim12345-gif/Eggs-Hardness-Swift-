//
//  ViewController.swift
//  EggTimer
//
//  Created by Angela Yu on 08/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var player: AVAudioPlayer!

    
    
    @IBOutlet weak var progressBar: UIProgressView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    let eggTimers = ["Soft": 3 ,"Medium": 4,"Hard": 7]

    // Timer (countDown)
    var totalTime = 0
    var secondsPassed = 0
    // have to create a varibale
    var clock = Timer()
    

    @IBAction func HardnessSelected(_ sender: UIButton) {
      
        let hardness = sender.currentTitle!
    // Timer , check it from apple documentaion for more inforamtion
            //selector : The message to send to target when the timer fires.
            // if the repeats are not true then it will not make the countdown it will just show 60 only , but true will make the countdown happen
           totalTime = eggTimers[hardness]!
        //Stops the timer from ever firing again and requests its removal from its run loop., this is the
        // only way to stop the timer , so it wont speed up
            clock.invalidate()
        

            clock = Timer.scheduledTimer(timeInterval: 1.0, target:self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
        
        // restart , i had an error with hardness becuase i put the code before the let hardness , but now its fine
        
        progressBar.progress=1.0 // the 1.0 is the full amount of the Progressbar
        // restart
        progressBar.progress = 0.0 // this is the progress bar
        secondsPassed = 0
        titleLabel.text = hardness // once we select one of the eggs it will change the label so either easy,meduim or hard
        

    

    }
 @objc func updateTimer() {
    //example functionality
    if secondsPassed < totalTime {
        secondsPassed += 1
        // we had to convert each one to float because they were integers
        let percetnageProgress = Float(secondsPassed)/Float(totalTime) // dividing both to get the percetange remaining for the bar
        progressBar.progress = percetnageProgress // we have to convert int of the percetangeprogress to float to match progressbar
        print(percetnageProgress)
        
        
        
       
    }else if secondsPassed == 0 {
        clock.invalidate() // stop the timer
        titleLabel.text = "Time is done!"
        // once we select harness it should make a noise
        let url = Bundle.main.url(forResource: "alarm_sound", withExtension: "mp3")
        player = try! AVAudioPlayer(contentsOf: url!)
        player.play()

    }
    }
    
    
    
   
    
}


